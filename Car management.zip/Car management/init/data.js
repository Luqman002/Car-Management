const cars = [
  {
      name: 'Tesla Model S',
      description: 'A luxury electric sedan with impressive range and cutting-edge technology.',
      price: 8000000,
      location: 'California, USA',
      manufacturer: 'Tesla',
      image: '/images/tesla.jpg',
      _id: 'car123'
  },
  {
      name: 'Ford Mustang GT',
      description: 'A classic American muscle car with a powerful V8 engine and stylish design.',
      price: 6000000,
      location: 'Detroit, USA',
      manufacturer: 'Ford',
      image: '/images/mustang.jpg',
      _id: 'car124'
  },
  {
      name: 'BMW M3',
      description: 'A high-performance sports sedan with precise handling and a turbocharged engine.',
      price: 7000000,
      location: 'Munich, Germany',
      manufacturer: 'BMW',
      image: '/images/bmw.jpg',
      _id: 'car125'
  },
  {
      name: 'Audi A6',
      description: 'A premium executive sedan that combines luxury, performance, and technology.',
      price: 7500000,
      location: 'Ingolstadt, Germany',
      manufacturer: 'Audi',
      image: '/images/audi.jpg',
      _id: 'car126'
  },
  {
      name: 'Mercedes-Benz C-Class',
      description: 'A compact executive car that offers luxury features and advanced technology.',
      price: 6800000,
      location: 'Stuttgart, Germany',
      manufacturer: 'Mercedes-Benz',
      image: '/images/mercedes.jpg',
      _id: 'car127'
  },
  {
      name: 'Honda Civic Type R',
      description: 'A sporty hatchback with a turbocharged engine and a focus on performance.',
      price: 4000000,
      location: 'Tokyo, Japan',
      manufacturer: 'Honda',
      image: '/images/civic.jpg',
      _id: 'car128'
  },
  {
      name: 'Porsche 911 Carrera',
      description: 'An iconic sports car known for its rear-engine design and high performance.',
      price: 12000000,
      location: 'Stuttgart, Germany',
      manufacturer: 'Porsche',
      image: '/images/porsche.jpg',
      _id: 'car129'
  },
  {
      name: 'Chevrolet Camaro',
      description: 'A powerful muscle car with a bold design and strong performance.',
      price: 5500000,
      location: 'Detroit, USA',
      manufacturer: 'Chevrolet',
      image: '/images/camaro.jpg',
      _id: 'car130'
  },
  {
      name: 'Nissan GT-R',
      description: 'A high-performance sports car known as "Godzilla" for its speed and agility.',
      price: 9500000,
      location: 'Yokohama, Japan',
      manufacturer: 'Nissan',
      image: '/images/gtr.jpg',
      _id: 'car131'
  },
  {
      name: 'Lamborghini Huracán',
      description: 'A supercar with a striking design, a V10 engine, and extraordinary performance.',
      price: 25000000,
      location: 'Sant\'Agata Bolognese, Italy',
      manufacturer: 'Lamborghini',
      image: '/images/lamborghini.jpg',
      _id: 'car132'
  }
];
  
  module.exports = { data: cars };